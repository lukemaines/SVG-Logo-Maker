# SVG-Logo-Maker
Node.js command application that generates a logo and saves it as an SVG file
